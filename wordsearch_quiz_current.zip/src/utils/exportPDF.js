// src/utils/exportPDF.js
// Exporter with configurable margins and image fit.
// - imageFit: "cover" (default) or "contain"
// - margins: pass either opts.marginPt (points) or opts.marginMM (millimetres)
//   Defaults to ~10mm = 28pt.
// Includes two exporters:
//   exportTriviaPDF          (same-tab)
//   exportTriviaPDFInIframe  (hidden iframe; recommended)

import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

const SIZES = {
  A4:     { wPt: 595, hPt: 842, wMM: 210, hMM: 297 },
  Letter: { wPt: 612, hPt: 792, wMM: 216, hMM: 279 }
};

function collectPages() {
  return Array.from(document.querySelectorAll("._a4"));
}

function mmToPt(mm) {
  return (mm * 72.0) / 25.4; // 1 inch = 25.4mm, 1 inch = 72pt
}

function resolveMargins(opts) {
  if (typeof opts.marginPt === "number") return Math.max(0, opts.marginPt);
  if (typeof opts.marginMM === "number") return Math.max(0, mmToPt(opts.marginMM));
  return 28; // default ~10mm
}

// Draw captured image to PDF page using chosen fit and margins
function addImageFitted(pdf, imgData, S, fit, marginPt) {
  const props = pdf.getImageProperties(imgData);
  const pageW = S.wPt, pageH = S.hPt;
  const imgW = props.width, imgH = props.height;

  const availW = Math.max(1, pageW - 2 * marginPt);
  const availH = Math.max(1, pageH - 2 * marginPt);

  const scaleContain = Math.min(availW / imgW, availH / imgH);
  const scaleCover   = Math.max(availW / imgW, availH / imgH);
  const scale = (fit === "contain") ? scaleContain : scaleCover;

  const w = imgW * scale;
  const h = imgH * scale;

  const x = (pageW - w) / 2;
  const y = (pageH - h) / 2;

  pdf.addImage(imgData, "JPEG", x, y, w, h);
}

function overlaysForNode(node, opts) {
  const added = [];
  const bgSrc = opts.bgSrc || "";
  const bgOpacity = typeof opts.bgOpacity === "number" ? opts.bgOpacity : 0.08;
  const logoSrc = opts.logoSrc || "";
  const footerText = opts.footerText || "";

  if (bgSrc) {
    const bg = document.createElement("div");
    Object.assign(bg.style, {
      position: "absolute",
      inset: "0",
      backgroundImage: `url('${bgSrc}')`,
      backgroundSize: "cover",
      backgroundPosition: "center",
      opacity: String(bgOpacity),
      zIndex: "0",
      pointerEvents: "none"
    });
    if (!node.style.position) node.style.position = "relative";
    node.prepend(bg);
    added.push(bg);
  }
  if (logoSrc) {
    const logo = document.createElement("img");
    logo.src = logoSrc;
    Object.assign(logo.style, {
      position: "absolute",
      top: "6mm",
      right: "6mm",
      maxWidth: "40mm",
      maxHeight: "18mm",
      objectFit: "contain",
      zIndex: "2",
      pointerEvents: "none"
    });
    node.appendChild(logo);
    added.push(logo);
  }
  if (footerText) {
    const foot = document.createElement("div");
    foot.textContent = footerText;
    Object.assign(foot.style, {
      position: "absolute",
      bottom: "6mm",
      left: "0",
      right: "0",
      textAlign: "center",
      fontSize: "9pt",
      opacity: "0.8",
      zIndex: "2",
      pointerEvents: "none"
    });
    node.appendChild(foot);
    added.push(foot);
  }
  return function cleanup() {
    added.forEach(n => { try { n.remove(); } catch (_) {} });
  };
}

// =======================
// SAME-TAB EXPORT (UI may be blocked on big packs)
// =======================
export async function exportTriviaPDF(opts = {}, onProgress = () => {}) {
  const pages = collectPages();
  if (!pages.length) { alert("No pages found (._a4)."); return; }

  const size = opts.size || "A4";
  const S = SIZES[size] || SIZES.A4;
  const bw = !!opts.bw;
  const imageFit = opts.imageFit === "contain" ? "contain" : "cover"; // default cover
  const marginPt = resolveMargins(opts);
  const renderScale = typeof opts.renderScale === "number" ? opts.renderScale : 1.8;
  const jpegQuality = typeof opts.jpegQuality === "number" ? Math.max(0.5, Math.min(0.95, opts.jpegQuality)) : 0.92;

  onProgress("init", { total: pages.length });

  // Preload images
  const imgs = pages.flatMap(n => Array.from(n.querySelectorAll("img")));
  const toLoad = imgs.filter(img => !img.complete);
  if (toLoad.length) {
    await Promise.all(toLoad.map(img => new Promise(res => { img.onload = img.onerror = () => res(); })));
  }
  onProgress("ready");

  // Overlays + grayscale in-place
  const cleanups = pages.map(n => overlaysForNode(n, opts));
  const filterReverts = [];
  if (bw) {
    pages.forEach(n => {
      const prev = n.style.filter;
      n.style.filter = (prev ? prev + " " : "") + "grayscale(100%) contrast(110%)";
      filterReverts.push(() => { n.style.filter = prev || ""; });
    });
  }

  try {
    onProgress("start", { total: pages.length });
    const pdf = new jsPDF({ unit: "pt", format: [S.wPt, S.hPt], compress: true });

    for (let i = 0; i < pages.length; i++) {
      onProgress("render", { page: i + 1, total: pages.length });
      await new Promise(r => (window.requestIdleCallback ? requestIdleCallback(() => r()) : setTimeout(() => r(), 0)));

      const canvas = await html2canvas(pages[i], {
        scale: renderScale,
        backgroundColor: "#ffffff",
        useCORS: true,
        allowTaint: true,
        logging: false
      });

      const img = canvas.toDataURL("image/jpeg", jpegQuality);
      if (i > 0) pdf.addPage([S.wPt, S.hPt]);
      addImageFitted(pdf, img, S, imageFit, marginPt);

      try {
        canvas.width = 1; canvas.height = 1;
        const ctx = canvas.getContext("2d");
        if (ctx) ctx.clearRect(0, 0, 1, 1);
      } catch (_) {}
    }

    onProgress("save");
    pdf.save("trivia_pack.pdf");
    onProgress("done");
  } catch (err) {
    console.error("[exportTriviaPDF] failed:", err);
    onProgress("error", { error: String(err) });
    alert("Export failed.");
  } finally {
    cleanups.forEach(fn => { try { fn && fn(); } catch(_){} });
    filterReverts.forEach(fn => { try { fn && fn(); } catch(_){} });
  }
}

// =======================
// BACKGROUND EXPORT (hidden iframe; recommended)
// =======================

function escJsSingleQuoted(s) {
  return String(s).replace(/\\/g, "\\\\").replace(/'/g, "\\'");
}
function escCssUrl(s) {
  // very basic; enough for data URLs / http(s) links
  return String(s).replace(/[)\\]/g, "\\$&");
}

export async function exportTriviaPDFInIframe(opts = {}, onProgress = () => {}) {
  const pages = collectPages();
  if (!pages.length) { alert("No pages found (._a4)."); return; }

  const size = opts.size || "A4";
  const S = SIZES[size] || SIZES.A4;
  const bw = !!opts.bw;
  const imageFit = opts.imageFit === "contain" ? "contain" : "cover"; // default cover
  const marginPt = resolveMargins(opts);
  const renderScale = typeof opts.renderScale === "number" ? opts.renderScale : 1.6;
  const jpegQuality = typeof opts.jpegQuality === "number" ? Math.max(0.5, Math.min(0.95, opts.jpegQuality)) : 0.9;

  const bgSrc = opts.bgSrc || "";
  const bgOpacity = typeof opts.bgOpacity === "number" ? opts.bgOpacity : 0.08;
  const logoSrc = opts.logoSrc || "";
  const footerText = opts.footerText || "";

  const bodyFilter = bw ? "grayscale(100%) contrast(110%)" : "none";
  const cssBg = bgSrc ? `background-image:url('${escCssUrl(bgSrc)}');` : "";
  const pagesHTML = pages.map(el => el.outerHTML).join("\n");

  const iframe = document.createElement("iframe");
  Object.assign(iframe.style, { position: "fixed", width: "0", height: "0", border: "0", opacity: "0" });
  iframe.setAttribute("aria-hidden", "true");
  document.body.appendChild(iframe);

  // Optional injections
  const logoInject = logoSrc
    ? `
      nodes.forEach(function(n){
        var i = document.createElement('img');
        i.src = '${escJsSingleQuoted(logoSrc)}';
        i.className = 'x-header-logo';
        n.appendChild(i);
      });
    `
    : "";

  const footerInject = footerText
    ? `
      nodes.forEach(function(n){
        var f = document.createElement('div');
        f.className = 'x-footer';
        f.textContent = '${escJsSingleQuoted(footerText)}';
        n.appendChild(f);
      });
    `
    : "";

  // Inner script that runs in the iframe
  const workerScript = `
  (function(){
    var jsPDFU = window.jspdf.jsPDF;
    var tell = function(type, data){
      parent.postMessage({ source: 'trivia-export-bg', type: type, total: (data && data.total) || 0, page: (data && data.page) || 0 }, '*');
    };

    var nodes = [].slice.call(document.querySelectorAll('._a4'));
    ${logoInject}
    ${footerInject}

    tell('init', { total: nodes.length });

    Promise.resolve().then(async function(){
      // wait any remaining images
      var pending = [].slice.call(document.images).filter(function(im){ return !im.complete; });
      if (pending.length) {
        await Promise.all(pending.map(function(im){ return new Promise(function(r){ im.onload = im.onerror = function(){ r(); }; }); }));
      }
      tell('ready');

      var pdf = new jsPDFU({ unit: 'pt', format: [${S.wPt}, ${S.hPt}], compress: true });
      tell('start', { total: nodes.length });

      for (var i = 0; i < nodes.length; i++) {
        tell('render', { page: i + 1, total: nodes.length });
        await new Promise(function(r){ (window.requestIdleCallback ? requestIdleCallback(function(){ r(); }) : setTimeout(function(){ r(); }, 0)); });

        var c = await html2canvas(nodes[i], {
          scale: ${renderScale},
          backgroundColor: '#ffffff',
          useCORS: true,
          allowTaint: true,
          logging: false
        });
        var img = c.toDataURL('image/jpeg', ${jpegQuality});
        if (i > 0) pdf.addPage([${S.wPt}, ${S.hPt}]);

        // fit
        var props = pdf.getImageProperties(img);
        var pageW = ${S.wPt}, pageH = ${S.hPt}, imgW = props.width, imgH = props.height;
        var marginPt = ${marginPt};
        var availW = Math.max(1, pageW - 2 * marginPt), availH = Math.max(1, pageH - 2 * marginPt);
        var scaleContain = Math.min(availW / imgW, availH / imgH), scaleCover = Math.max(availW / imgW, availH / imgH);
        var scale = ('${imageFit}' === 'contain') ? scaleContain : scaleCover;
        var w = imgW * scale, h = imgH * scale, x = (pageW - w) / 2, y = (pageH - h) / 2;
        pdf.addImage(img, 'JPEG', x, y, w, h);
      }

      tell('save');
      pdf.save('trivia_pack.pdf');
      tell('done');
    }).catch(function(e){
      console.error(e);
      tell('error', { error: String(e && e.message || e) });
    });
  })();
  `;

  const html = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8"/>
    <title>Export</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
      *{box-sizing:border-box} body{margin:0}
      ._a4{
        width:${S.wMM}mm;
        min-height:${S.hMM}mm;
        background:#fff;
        position:relative;
        overflow:hidden;
        z-index:0;
        padding:0;
      }
      ._a4>*{position:relative; z-index:1}
      ._a4::before{
        content:'';
        position:absolute; inset:0;
        ${cssBg}
        background-size:cover;
        background-position:center;
        opacity:${bgSrc ? Number(bgOpacity) : 0};
        z-index:0; pointer-events:none;
      }
      .x-header-logo{position:absolute; top:6mm; right:6mm; z-index:2; max-width:40mm; max-height:18mm; object-fit:contain}
      .x-footer{position:absolute; bottom:6mm; left:0; right:0; text-align:center; font-size:9pt; opacity:.8; z-index:2}
    </style>
  </head>
  <body style="filter:${bodyFilter}">
    ${pagesHTML}
    <script>${workerScript.replace(/<\/script>/gi, "<\\/script>")}<\/script>
  </body>
</html>`.trim();

  const doc = iframe.contentDocument;
  doc.open(); doc.write(html); doc.close();

  function onMsg(e) {
    const d = e && e.data ? e.data : {};
    if (d.source !== "trivia-export-bg") return;
    onProgress(d.type, d);
    if (d.type === "done" || d.type === "error") {
      window.removeEventListener("message", onMsg);
      setTimeout(() => { try { iframe.remove(); } catch(_) {} }, 500);
    }
  }
  window.addEventListener("message", onMsg);
}

