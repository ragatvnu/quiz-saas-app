import React from "react"
import WordSearch from "../components/WordSearch.jsx"
import { loadTheme } from "../data/loadTheme.js"

export default function WordSearchPage(){
  const THEME = loadTheme("animals")
  const p = THEME.puzzles.find(x => x.type === "word_search") || THEME.puzzles[0]
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white text-gray-900">
      <div className="sticky top-0 z-30 bg-white/80 backdrop-blur border-b print:hidden">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-3">
          <h1 className="text-lg font-bold">Word Search</h1>
          <button onClick={()=>window.print()} className="ml-auto px-3 py-1.5 rounded-xl bg-black text-white text-sm">Print / Save PDF</button>
        </div>
      </div>
      <div className="max-w-5xl mx-auto px-4 py-8">
        <WordSearch data={p} showAnswers={false} />
      </div>
      <style>{`@page{size:A4;margin:12mm}@media print{.sticky{display:none!important}}`}</style>
    </div>
  )
}
